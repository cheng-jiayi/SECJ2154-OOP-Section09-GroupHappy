public class FullCarpoolException extends Exception {
    public FullCarpoolException(String message) {
        super(message);
    }
}